package 메서드연습;

public class 계산기3 {
	public int add(int x, int y) {
	return x + y;
	}
	public int minus(int x, int y) {
		return x - y;
	}
	public int multi(int x, int y) {
		return x * y;
	}
	public int division(int x, int y) {
		return x / y;
	}
}
