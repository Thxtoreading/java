package 메서드연습;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.FlowLayout;


public class 역전우동 {
	static int index = 0;
	static int count;
	static int total;
	final static int PRICE = 5000; //final은 변경불가, 상수
	// 상수 변수를 쓸 때는 잘 보이라고 변수명을 모두 대문자로!

	public static void main(String[] args) {
		//프레임, 버튼 3개, 텍스트필드, 이미지, 라벨4
		String [] img = {"tkwls/udon.png", "tkwls/momil.png", "tkwls/bob.png"};
		
		JFrame f = new JFrame("역전우동");
		f.setSize(450,400);
		f.getContentPane().setBackground(Color.lightGray);
		
		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);
		
		Font font = new Font("나눔고딕", Font.BOLD, 30);
		Font font2 = new Font("나눔고딕", Font.BOLD, 20);
		
		JLabel textLabel = new JLabel("개수: ");
		textLabel.setFont(font);
		JLabel countLabel = new JLabel("0개");
		countLabel.setFont(font);
		JLabel imgLabel = new JLabel();
		ImageIcon icon = new ImageIcon("tkwls/home.png");
		imgLabel.setIcon(icon);
		JLabel result = new JLabel("결제 금액: 0원");
		result.setFont(font);
		
		//버튼
		JButton udon = new JButton("우동");
		udon.setFont(font);
		udon.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon(img[0]);
				imgLabel.setIcon(icon);
				count++;
				countLabel.setText(count + "개");
				total = (PRICE*count);
				result.setText("결제 금액: " + total + "원");
				
			}
		}); //action end
		
		JButton momil = new JButton("모밀");
		momil.setFont(font);
		momil.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon(img[1]);
				imgLabel.setIcon(icon);
				count++;
				countLabel.setText(count + "개");
				total = (PRICE*count);
				result.setText("결제 금액: " + total + "원");
				
			}
		}); //action end
		
		JButton bob = new JButton("덮밥");
		bob.setFont(font);
		bob.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon(img[2]);
				imgLabel.setIcon(icon);
				count++;
				countLabel.setText(count + "개");
				total = (PRICE*count);
				result.setText("결제 금액: " + total + "원");
				
			}
		}); //action end
		
		
		f.add(udon);
		f.add(momil);
		f.add(bob);
		f.add(textLabel);
		f.add(countLabel);
		f.add(imgLabel);
		f.add(result);
		
		
		
		
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		f.setVisible(true);

	}

}
