package 메서드연습;

public class 내가게3 {

	public static void main(String[] args) {
		계산기3 cal3 = new 계산기3();
		int price = 7000;
		int count1 = 5; //오전
		int count2 = 4; //오후
		
		//1. 전체 손님 수를 반환받아서 다음과 같이 프린트 // 오늘 온 손님의 총 합은 9명 입니다.
		int cus = cal3.add(count1, count2);
		System.out.println("오늘 온 손님의 총 합은 " + cus + "명 입니다.");
		
		//2. 오전과 오후 손님수 차이는? //Math.abs => 절대값으로 사용 가능
		int gap = cal3.minus(count1, count2);
		System.out.println("손님 수 차이는 " + Math.abs(gap) + "명 입니다.");
		//ceil => 올립, floor => 내림, round => 반올림, sqrt => 루트, max는 두개 중만 가능, pow => 제곱
		
		//3. 오전에 들어온 손님의 결제 금액은?
		int amPrice = cal3.multi(price, count1);
		System.out.println("오전 결제 금액은 " + amPrice + "원 입니다.");
		
		//4. 오후에 들어온 손님의 결제 금액은?
		int pmPrice = cal3.multi(price, count2);
		System.out.println("오후 결제 금액은 " + pmPrice + "원 입니다.");
		
		//5. 오전과 오후에 들어온 손님의 총 결제 금액은?
		int totalPrice = cal3.add(amPrice, pmPrice);
		System.out.println("오늘 하루 총 결제 금액은 " + totalPrice + "원 입니다.");
		
		//6. 5번에서 계산한 결제 금액으로 1인당 결제 금액을 계산해 주세요.
		int perPrice = cal3.division(totalPrice, cus);
		System.out.println("1인당 결제 금액은 " + perPrice + "원 입니다.");

	}
}
