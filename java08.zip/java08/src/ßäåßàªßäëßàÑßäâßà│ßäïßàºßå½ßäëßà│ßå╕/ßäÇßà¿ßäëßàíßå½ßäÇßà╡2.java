package 메서드연습;

public class 계산기2 {
	// 메서드 이름을 입력값이 다르면, 다 동일하게 써도 된다.
	// 하나의 이름으로 다양한 형태 구현 가능
	// ==> '다형성(오버로딩)'이라 부르는 특징임
	public int add(int x, int y) {
		return x + y;
	}
	public double add(int x, double y) {
		return x + y;
	}
	public double add(double x, double y) {
		return x + y;
	}
	public String add(String x, int y) {
		return x + y + "시에 점심을 먹겠어.";
	}
}
