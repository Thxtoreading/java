package 메서드연습;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class 영화예매시스템 {
	static int count;
	static int count1;
	static int count2;
	static int count3;
	static int count4;

	static int adultPrice = 8000;
	static int teenPrice = 7000;
	static int childPrice = 5000;
	static int seniorPrice = 5000;
	static int total;
	static int index = 1;

	public static void main(String[] args) {
		String[] title = { "더 퍼스트 슬램덩크", "타이타닉", "아바타: 물의 길" };
		String[] img = { "tkwls/001.png", "tkwls/002.png", "tkwls/003.png" };

		JFrame f = new JFrame();
		f.setSize(400, 430);
		f.getContentPane().setBackground(Color.lightGray);

		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);

		Font font = new Font("나눔고딕", Font.BOLD, 15);
		Font font2 = new Font("나눔고딕", Font.BOLD, 20);
		Font font3 = new Font("나눔고딕", Font.BOLD, 30);
		Font font4 = new Font("나눔고딕", Font.BOLD, 50);

		ImageIcon icon = new ImageIcon(img[index]);
		JLabel imgLabel = new JLabel();
		imgLabel.setIcon(icon);

		JLabel titleLabel = new JLabel(title[index]);
		titleLabel.setFont(font4);
		JLabel result = new JLabel("총 결제 금액은 0원");
		result.setFont(font3);
		JLabel countLabel = new JLabel("0명");

		JButton adult = new JButton(" 성인 ");
		adult.setFont(font);
		adult.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				count++;
				count1++;
				countLabel.setText(count + "명");
				f.setTitle("성인: " + count1 + "명  청소년: " + count2 + "명  어린이: " + count3 + "명  시니어: " + count4 + "명");
				total = (adultPrice * count1) + (teenPrice * count2) + (childPrice * count3) + (seniorPrice * count4);
				result.setText("총 결제 금액: " + total + "원");
				if (total >= 100000) {
					JOptionPane.showMessageDialog(f, "한도초과");
				}

			}
		}); // action end

		JButton teen = new JButton("청소년");
		teen.setFont(font);
		teen.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				count++;
				count2++;
				countLabel.setText(count + "명");
				f.setTitle("성인: " + count1 + "명  청소년: " + count2 + "명  어린이: " + count3 + "명  시니어: " + count4 + "명");
				total = (adultPrice * count1) + (teenPrice * count2) + (childPrice * count3) + (seniorPrice * count4);
				result.setText("총 결제 금액: " + total + "원");
				if (total >= 100000) {
					JOptionPane.showMessageDialog(f, "한도초과");
				}

			}
		}); // action end

		JButton child = new JButton("어린이");
		child.setFont(font);
		child.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				count++;
				count3++;
				countLabel.setText(count + "명");
				f.setTitle("성인: " + count1 + "명  청소년: " + count2 + "명  어린이: " + count3 + "명  시니어: " + count4 + "명");
				total = (adultPrice * count1) + (teenPrice * count2) + (childPrice * count3) + (seniorPrice * count4);
				result.setText("총 결제 금액: " + total + "원");
				if (total >= 100000) {
					JOptionPane.showMessageDialog(f, "한도초과");
				}

			}
		}); // action end

		JButton senior = new JButton("시니어");
		senior.setFont(font);
		senior.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				count++;
				count4++;
				countLabel.setText(count + "명");
				f.setTitle("성인: " + count1 + "명  청소년: " + count2 + "명  어린이: " + count3 + "명  시니어: " + count4 + "명");

				total = (adultPrice * count1) + (teenPrice * count2) + (childPrice * count3) + (seniorPrice * count4);
				result.setText("총 결제 금액: " + total + "원");
				if (total >= 100000) {
					JOptionPane.showMessageDialog(f, "한도초과");
				}

			}
		}); // action end

		JButton left = new JButton();
		left.setText("<");
		left.setFont(font2);
		left.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				titleLabel.setText(title[index -1] + "");
				ImageIcon icon = new ImageIcon(img[index - 1]);
				imgLabel.setIcon(icon);
				index--;
				if (index == -1) {
					JOptionPane.showMessageDialog(f, "첫 번째 영화입니다.");
				}

			}
		}); // action end

		JButton right = new JButton();
		right.setText(">");
		right.setFont(font2);
		right.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				titleLabel.setText(title[index + 1] + "");
				ImageIcon icon = new ImageIcon(img[index + 1]);
				imgLabel.setIcon(icon);
				index++;
				if (index == 3) {
					JOptionPane.showMessageDialog(f, "마지막 영화입니다.");
				}

			}
		}); // action end

		f.add(adult);
		f.add(teen);
		f.add(child);
		f.add(senior);
		f.add(countLabel);
		f.add(left);
		f.add(imgLabel);
		f.add(right);
		f.add(titleLabel);
		f.add(result);

		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		f.setVisible(true);

	}

}
