package 연산자;

public class 비교연산자 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 비교연산자(==, !=, >, >=)
		// 비교 결과가 중요 (논리형 데디터)
		int x = 20;
		int y = 10;
			
	}

}
