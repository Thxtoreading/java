package 변수;

public class Hi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("안녕하세요.^^ 저는 이클립스랍니다.");
		System.out.println("안녕하세요.^^ 저는 이클립스랍니다.");
		System.out.println("5교시 수업입니다.");
		System.out.println("6교시 수업입니다.");
		System.out.println("5교시 수업입니다.");
		System.out.println("5교시 수업입니다.");

	}

}
