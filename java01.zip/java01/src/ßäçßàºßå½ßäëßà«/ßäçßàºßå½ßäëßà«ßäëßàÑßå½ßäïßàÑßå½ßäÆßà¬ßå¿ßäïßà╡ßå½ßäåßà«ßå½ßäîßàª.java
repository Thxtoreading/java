package 변수;

public class 변수선언확인문제 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age = 20;
		//int는 21억까지 들어감, 이것만 사용하면 메모리 낭비, int는 4바이트니
		//표현 가능한 숫자 범위로 나눠짐
		//128까지 표현 -> byte, 3만까지 표현 -> short
		
		double tall = 158.3;
		//실수 소수점 자릿수로 메모리 크기가 바뀜
		//소수점 4자리는 float, 8자리는 double
		char gender = '여'; 
		boolean breakfast = false;
		 
		//기본 데이터는 X ==> 너무 많이 쓰기 때문에 기본형처럼 사용 가능!
		String name = "정서현"; //여러 글자를 쓸때는 ""
		// 한글자가 넘을 떄는 char를 쓰지 않음 
		// 스트링, 실! -> 한글자씩 꼬매서 실로 연결해야겠다 -> 실타입, 문자열!
		// char는 ''(작은 따옴표 사용), string은 ""(큰 따옴표 사용)
		// 부품은 첫글자를 대문자로 사용(System, String 등등)
		
		System.out.println("나의 이름은 " + name + "입니다.");
		System.out.println("나의 나이는 " + age);
		System.out.println("나의 키는 " + tall);
		System.out.println("나의 성별은 " + gender);
		System.out.println("나의 아침식사는 " + breakfast);

	}

}
