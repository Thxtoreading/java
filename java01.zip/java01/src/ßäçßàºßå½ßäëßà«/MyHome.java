package 변수;

public class MyHome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int myAge = 20;
		
		// 전화번호 01046004123
		String myTel = "01046004123"; 
		//자릿수가 의미없으면 string, 의미가 있으면 int나 double
		
		String ssn = "040227";
		// 주민번호 040227
		
		// 절대 값을 변하게 하지 말아줘!! 값을 설정
		final double PI = 3.14;
		//final은 변경 불가, 마지막일때, 수정없을 때 사용
		//상수변수 ==> final, 변수명을 다 대문자로!
		
	}

}
