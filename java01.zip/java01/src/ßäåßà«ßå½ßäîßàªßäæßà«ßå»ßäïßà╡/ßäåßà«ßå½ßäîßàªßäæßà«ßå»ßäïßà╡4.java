package 문제풀이;

public class 문제풀이4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int money = 18000;
		double score = 4.8;
		char location = '한';
		boolean week = false;

	}

}
