package 문제풀이;

public class 문제풀이2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1 = 30;
		int num2 = 40;
		
		System.out.println(num1 / num2);
		System.out.println(num1 % num2);
		

	}

}
