package 문제풀이;

import javax.swing.JOptionPane;

public class 문제풀이1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//입력
		String date = JOptionPane.showInputDialog("오늘은 무슨 요일인가요?");
		String wht = JOptionPane.showInputDialog("수업 끝나고 무엇을 하실 예정인가요?");
		
		//처리
		String result = "오늘" + date + "에 수업 후 나는 " + wht + "할 예정";
		System.out.println(result);

	}

}
