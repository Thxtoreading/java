package 문제풀이;

public class 문제풀이3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double x = 33.3;
		double y = 22.2;
		
		System.out.println(x == 44.4);
		
		

	}

}
