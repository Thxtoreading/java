package 복습;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class 부품조립하기 {

	public static void main(String[] args) {
		// 1. 자주 써서 RAM에 언제든 사용할 수 있도록 준비되어 있음.
		//    부품명. 기능();
		//    망치같은 역할
		
		//2. 쓸 때마다 제공되는 틀을 이용해서 찍어내어
		//   여러 개 만들어 RAM에 저장해두고 사용
		//   벽돌같은 역할
		//   벽돌(변수) b = new 벽돌();
		//   [ex: JFrame f = new JFrame();]
		
		//부품은 개 필요함
		//JFrame, JLable, JTextField, JButton
		//FlowLayout
		//Font, Color
		
		JFrame f = new JFrame();
		f.setSize(400,300);
		
		JLabel la = new JLabel();
		la.setText("당신이 생각한 숫자를 입력하시오.");
		
		JTextField tex = new JTextField(10);
		JButton b = new JButton();
		b.setText("숫자 맞추기 게임");
		
		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);
		
		Font font = new Font("나눔고", 1, 40);
		Font font2 = new Font("나눔고딕", 1, 30);
		f.add(la);
		f.add(tex);
		f.add(b);
		
		la.setFont(font2);
		la.setForeground(Color.gray);
		
		tex.setFont(font);
		b.setBackground(Color.red);
		b.setFont(font);
		f.getContentPane().setBackground(Color.green);
		
		//맨 아래
		f.setVisible(true);

	}

}
