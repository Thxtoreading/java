package 조건문;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class 인기조사10명 {

	public static void main(String[] args) {
		//인기투표 해 봅시다!
		//1) 아이유 2)뉴진스 3)BTS
		
		//타입 정리
		int iu = 0;
		int newj = 0;
		int bts = 0;

		//입력, 처리
		for (int i = 0; i < 10; i++) {
			String data = JOptionPane.showInputDialog("좋아하는 사람의 번호를 적어 주세요. 1) 아이유 2) 뉴진스 3) BTS");
			if (data.equals("1")) {
				iu++;
			} else if (data.equals("2")) {
				newj++;
			}else if (data.equals("3")) {
				bts++;
			} //else 
		} //for
		
		
		//출력
		System.out.println("아이유를 좋아하는 사람은 " + iu + "명 입니다.");
		System.out.println("뉴진스를 좋아하는 사람은 " + newj + "명 입니다.");
		System.out.println("유재석을 좋아하는 사람은 " + bts + "명 입니다.");
		JFrame fr = new JFrame();
		fr.setSize(400, 400);
		
		JOptionPane.showMessageDialog(fr, iu + "명이 아이유를 좋아합니다. \n" +  newj  + "명이 뉴진스를 좋아합니다. \n"  + bts + "명이 방탄소년단을 좋아합니다. \n");
		
		
	}

}
