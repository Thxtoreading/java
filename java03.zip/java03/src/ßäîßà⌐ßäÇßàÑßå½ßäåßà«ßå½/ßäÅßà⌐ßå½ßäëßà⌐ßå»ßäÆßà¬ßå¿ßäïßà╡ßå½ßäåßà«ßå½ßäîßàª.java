package 조건문;

import java.util.Scanner;

public class 콘솔확인문제 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("이름 입력 >>   ");
		String name = sc.next(); //한단어
		System.out.println("나이 입력 >>   ");
		int age = sc.nextInt();
		System.out.println("키 입력 >>   ");
		double high = sc.nextDouble();
		System.out.println("저녁을 먹었나요? (true/false) >>   ");
		boolean food = sc.nextBoolean();
		System.out.println("올해의 목표는? >>   ");
		sc.nextLine();
		String life = sc.nextLine();
		
		System.out.println("-------------------------------------");
		System.out.println("내 이름은 " + name + "입니다!");
		System.out.println("내년 나이는 " + (age + 1) + "이겠군요... ㅎ.ㅎ");
		System.out.println("내년 키는 " + (high + 1) + "이길 바랍니다!");
		if (food) {
			System.out.println("배가 부르시겠군요! *^^*");
		} else {
			System.out.println("배가 고프시겠군요 ㅠ.ㅠ");
		}
		System.out.println("올해의 목표는 " + life );
		
		
		sc.close();
	}

}
