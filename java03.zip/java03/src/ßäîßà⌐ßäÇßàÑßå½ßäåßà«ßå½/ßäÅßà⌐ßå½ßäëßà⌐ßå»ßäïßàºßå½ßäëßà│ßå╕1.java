package 조건문;

import java.util.Scanner;

public class 콘솔연습1 {

	public static void main(String[] args) {
		//연습 문제 1 나에 대한 정보 입력하기
		Scanner sc = new Scanner(System.in);
		System.out.println("나에 대한 정보");
		System.out.println("-----------------");
		System.out.println("이름 입력 >> ");
		String data = sc.next();
		
		System.out.println("나이 입력 >> ");
		int data2 = sc.nextInt();
		
		System.out.println("취미 입력 >> ");
		sc.nextLine();
		String data3 = sc.nextLine();
		System.out.println("-------------------");
		System.out.println("나의 이름은 " + data +"입니다.");
		System.out.println("나의 나이는 " + data2 +"세 입니다.");
		System.out.println("나의 취미는 " + data3 +"입니다.");
		
		sc.close();
	}

}
