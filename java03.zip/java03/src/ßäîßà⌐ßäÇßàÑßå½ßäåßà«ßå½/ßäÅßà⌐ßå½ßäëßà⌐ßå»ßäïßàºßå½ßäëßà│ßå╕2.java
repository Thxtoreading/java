package 조건문;

import java.util.Scanner;

public class 콘솔연습2 {

	public static void main(String[] args) {
		//연습 문제 1 나에 대한 정보 입력하기
		Scanner sc = new Scanner(System.in);
		System.out.println("나의 이름은?   ");
		String name = sc.next();
		
		System.out.println("나의 키는?   ");
		double high = sc.nextDouble();
		
		System.out.println("나의 몸무게는?   ");
		double weight = sc.nextDouble();
		
		System.out.println( "저녁은 먹었나요?     ");
		boolean dinner = sc.nextBoolean();
		
		System.out.println("나의 좌우명은?   ");
		sc.nextLine();
		String data = sc.nextLine();
		
		System.out.println("------------------------");
		
		System.out.println("내 이름은 " + name + "입니다.");
		System.out.println("나의 내년 키는 " + (10 + high) + "입니다.");
		System.out.println("나의 내년 몸무게는 " + (weight - 10) + "입니다.");
		System.out.println("나의 저녁 여부는 " + dinner + "입니다.");
		System.out.println("나의 좌우명은 " + data + " 입니다.");
		sc.close();
	}

}
