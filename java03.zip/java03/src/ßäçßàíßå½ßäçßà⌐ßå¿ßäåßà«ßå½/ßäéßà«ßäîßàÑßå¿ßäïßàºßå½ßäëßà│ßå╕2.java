package 반복문;

import java.util.Iterator;

import javax.swing.JOptionPane;

public class 누적연습2 {

	public static void main(String[] args) {
		//1. 숫자 누적
		//5부터 300까지 5의 배수만 모두 더해 출력해 보세요!
		int sum = 0;
		for (int i = 5; i <= 300; i++) {
			if (i % 5 != 0) {
				continue;
			}
			sum = sum + i;
		}
		System.out.println("합계는 " + sum + "입니다.");
		
		//2. 문자 누적
		//먹고 싶은 음식 4가지를 입력 받아서 나열해 보세요.
		
		String sum2 = "";
		for (int i = 0; i < 4; i++) {
			String data = JOptionPane.showInputDialog("먹고 싶은 음식을 입력 해 주세요~");
			sum2 = sum2 + data + "랑  ";
			
		}
		System.out.println("먹고 싶은 음식들 >> " + sum2 + "먹고 싶어 ㅠ.ㅠ");
		
	}

}
