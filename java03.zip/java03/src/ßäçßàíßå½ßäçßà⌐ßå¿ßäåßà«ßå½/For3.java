package 반복문;

import javax.swing.JOptionPane;

public class For3 {

	public static void main(String[] args) {
		//1번 문제
		for (int i = 0; i < 10.; i++) {
			System.out.print("*");
		}
		
		System.out.println();
		
		//2번 문제
		for (int i = 0; i < 5; i++) {
			System.out.print("커피*");
		}
		System.out.println();
		
		//3번 문제
		for (int i = 0; i < 3; i++) {
			System.out.println("커피*우유");
		}
		
		//4번 문제
		for (int i = 0; i < 3; i++) {
			System.out.println((i+1) + " : 짱!");
		}
		
	}

}
