package 반복문;

// ! ==> not의 의미 
public class 반복문안에서스킵하기 {

	public static void main(String[] args) {
		// 1번부터 10번까지 데이터 중에서 짝수만 프린트
		for (int i = 1; i <= 10; i++) { // < 11이라고 써도 됨. 그러나 '<=10'을 더 선호함.
			//i가 8이 되면 for문 종료
			if (i == 8) {
				break;
				//System.exit(0); 이렇게하면 시스템이 아예 종단
				//0 : 정상 종료, 0이 아닌 다른 값: 비정상 종료
			}
			if (i % 2 != 0) { //홀수
				continue; //조건에 맞는 i만 for문 안의 내용을 실행하지 않음
			}
			System.out.println(i);
		}
		System.out.println("휴~~ for문 다 끝낫당. @@");
	}
	//이자리는 메인 
}
