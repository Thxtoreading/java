package 반복문;

public class For1 {

	public static void main(String[] args) {
		// 3번 반복
		//for(초기값; 조건식; 증감식)
		for (int i = 0; i < 3; i++) {
			//괄호 안 = 지역
			//for 지역{  }안에서만 i변수는 사용 됨.
			// 지역변수(local), 반대로 전역변수도 있음.
			System.out.println(i + "내가 반복");
		}
		//100번 반복 -> 내가 반복2
		for (int i = 0; i < 100; i++) {
			System.out.println("내가 반복2  >> " + i);
		}
		
		//10번 반복 -> 내가 반복3 1번째 실행
		for (int i = 0; i < 10; i++) {
			System.out.println("내가 반복3 >> " + (i + 1) + "번째 실행중");
		}

	}

}
