package 반복문;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class 확인문제 {
	public static void main(String[] args) {
		//프레임 만들어야 해요.... 
		//JFrame, JButton 4개
		//Font, Color
		
		//프레
		JFrame fr = new JFrame();
		fr.setSize(400, 500);
		
		FlowLayout flow = new FlowLayout();
		fr.setLayout(flow);
		
		//버튼 설
		JButton b1 = new JButton();
		b1.setText("별 10");
		JButton b2 = new JButton();
		b2.setText("커피*5");
		JButton b3 = new JButton();
		b3.setText("커피*우유3");
		JButton b4 = new JButton();
		b4.setText("1:짱!");
		
		//폰트
		Font font = new Font("나눔고딕", 1, 60);
		b1.setFont(font);
		b2.setFont(font);
		b3.setFont(font);
		b4.setFont(font);
		
		//프레임 추가
		fr.add(b1);
		fr.add(b2);
		fr.add(b3);
		fr.add(b4);
		
		//1. 버튼에다가 액션기능을 추가하겠다고 설정
		//2. 클릭 액션이 있을 때 어떤 부품이 액션 처리를 어떻게 할지 코딩해 주면 됨.
		b1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// 클릭했을 때 처리하고 싶은 내용!
				System.out.println("b1를 클릭했음.");
				for (int i = 0; i < 10.; i++) {
					System.out.print("*");
				}
				
				System.out.println();	
			}
			
		});
		b2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("b2를 클릭했음.");
				for (int i = 0; i < 5; i++) {
					System.out.print("커피*");
				}
				System.out.println();
				
			}
			
		});
		b3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("b3를 클릭했음.");
				for (int i = 0; i < 3; i++) {
					System.out.println("커피*우유");
				}
				
			}
			
		});
		b4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("b1를 클릭했음.");
				for (int i = 0; i < 3; i++) {
					System.out.println((i+1) + " : 짱!");
				}
				
			}
			
		});
		
		//색깔
		fr.getContentPane().setBackground(Color.lightGray);
		
		fr.setVisible(true);
	}

}
