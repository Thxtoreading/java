package 반복문;

import javax.swing.JOptionPane;

public class For2 {

	//무한 루프(반복) //잘 사용하지 않음, while(true); 이것도 있음
	public static void main(String[] args) {
		for (; ;) { 
			System.out.println("잘 쓰지 않음!");
			String data = JOptionPane.showInputDialog("종료할까요? y를 입력");
			
			if (data.equals("y")) {
				System.out.println("안녕히 가세요!");
				break; //for문의 브레이크! if문의 브레이크 아님.
			} 
		}
	}

}
