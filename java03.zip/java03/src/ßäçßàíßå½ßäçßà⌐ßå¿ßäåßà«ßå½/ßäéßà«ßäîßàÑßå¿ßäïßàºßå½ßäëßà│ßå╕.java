package 반복문;

import javax.swing.JOptionPane;

public class 누적연습 {

	public static void main(String[] args) {
		// iu = iu + 1;
		// sum = sum +1;
		
		//숫자 누적
		int sum = 0; //0을 넣는 것을 '변수의 초기화'라고 함, 반드시 하기!
		for (int i = 1; i <= 1000; i++) {
			sum = sum + i;
			//System.out.println("현재까지의 합>> " + sum);
		}
		System.out.println("전체 합은 >> " + sum);
		
		//글자 누적
		String sum2 = ""; //String의 초기값은 ""(빈공간)을 넣어놓음
		for (int i = 0; i < 3; i++) {
			String data = JOptionPane.showInputDialog("가고 싶은 곳을 입력해 주세요!");
			sum2 = sum2  + data + " ";
		}
		System.out.println(sum2);
		
	}

}
