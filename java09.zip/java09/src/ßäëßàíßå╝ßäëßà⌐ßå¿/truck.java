package 상속;

public class truck extends Car {
	String kind;
	
	public void run() {
		System.out.println(kind + "를 싣고 달리다.");
	}
}
