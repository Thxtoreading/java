package 상속;

public class CoffeeTruck extends truck{
	boolean go;
	
	public void drive() {
		System.out.println("종류는 " + type);
		System.out.println("커피트럭을 운전해서 가다.");
	}
	
	@Override
	public void navi() {
		System.out.println("커피 공장으로");
		super.navi();
	}

	@Override
	public String toString() {
		return "CoffeeTruck [go=" + go + ", kind=" + kind + ", type=" + type + ", years=" + years + "]";
	}

}
