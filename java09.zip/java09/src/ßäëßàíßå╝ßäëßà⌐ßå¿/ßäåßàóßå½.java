package 상속;

public class 맨 extends 사람 {
	// Object의 것들도 있음.
	// name, age // eat(), sleep()
	int power;

	public void run() {
		System.out.println("빨리 달리다.");
	}
}
