package 상속;

public class 우먼 extends 사람 {
	int power2;
	
	public void face() {
		System.out.println("예쁘다");
	}
}
