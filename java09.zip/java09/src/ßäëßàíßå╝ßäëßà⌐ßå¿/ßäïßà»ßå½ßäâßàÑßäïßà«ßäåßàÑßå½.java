package 상속;

public class 원더우먼 extends 우먼 {
	boolean psychicPower;
	
	public void her() {
		sleep();
		System.out.println("이름은 " + name);
		System.out.println("사람을 구한다.");
	}
	
	@Override
	public void face() {
		System.out.println("갈수록 더 예쁘다");
		super.face();
	}

	@Override
	public String toString() {
		return "원더우먼 [psychicPower=" + psychicPower + ", power2=" + power2 + ", name=" + name + ", age=" + age + "]";
	}
	
}
