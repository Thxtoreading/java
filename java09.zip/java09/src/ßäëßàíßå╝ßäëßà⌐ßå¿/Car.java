package 상속;

public class Car extends Object{
	String type;
	int years;
	
	public void 시동키다() {
		System.out.println("부릉부릉");		
	}
	public void navi() {
		System.out.println("안내를 시작합니다.");
	}
	
	@Override
	public String toString() {
		return "Car [type=" + type + ", years=" + years + "]";
	}
	
}
