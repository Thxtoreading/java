package 상속;

public class 내차들 {
	
	public static void main(String[] args) {
		CoffeeTruck  car1 = new CoffeeTruck();
		car1.type = "트럭";
		car1.years = 3;
		car1.kind = "커피";
		car1.drive();
		car1.navi();
		car1.run();
		
	}
}
