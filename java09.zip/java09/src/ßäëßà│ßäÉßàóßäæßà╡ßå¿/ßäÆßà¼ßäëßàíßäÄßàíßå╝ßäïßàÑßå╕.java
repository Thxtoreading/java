package 스태픽;

public class 회사창업 {

	public static void main(String[] args) {
		직원 work1 = new 직원("홍길동", 25, '여');
		직원 work2 = new 직원("김길동", 24, '남');
		직원 work3 = new 직원("송길동", 26, '여');
		double agv = (double)직원.sum / 직원.count;
		
		System.out.println("직원들 정보 \n======================");
		System.out.println("이름 \t\t 나이 \t 성별");
		System.out.println(work1);
		System.out.println(work2);
		System.out.println(work3);
		System.out.println("=======================");
		System.out.println("총 " + 직원.count + "명 입니다.");
		System.out.println("평균 나이는 " + agv + "살 입니다.");
	}

}
