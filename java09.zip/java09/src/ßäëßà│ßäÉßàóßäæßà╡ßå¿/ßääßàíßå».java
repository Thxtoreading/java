package 스태픽;

public class 딸 {
	//멤버 변수
	String name;
	char gender;
	static int count;
	static int wallet = 10000;
	
	public 딸(String name, char gender) {
		super();
		count++;
		wallet -= 1000;
		this.name = name;
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "딸 [이름=" + name + ", 성별=" + gender + "]";
	}
	
	
	//멤버메서드
	public void tv보다() {
		
	}
}
