package 스태픽;

public class 직원 {
	String name;
	int age;
	char sex;
	static int count;
	static int sum;
	
	//객체생성하지 않고 클래스 이름으로 바로 접근해서 아무때나 원할 때 평균 구하고 싶은 경우
	// ==> static 메서드를 만들면 됨
	public static void getAvg() {
		// static메서드에서 전역변수를 접근할 때는 같은 성격을 가진 static 변수만 접근 가능
		System.out.println(sum/count);
	}
	public 직원(String name, int age, char sex) {
		super();
		count++;
		sum += age;
		this.name = name;
		this.age = age;
		this.sex = sex;
	}
	@Override
	public String toString() {
		return name + "\t  " + age + "\t\t   " + sex ;
	}
	
}
