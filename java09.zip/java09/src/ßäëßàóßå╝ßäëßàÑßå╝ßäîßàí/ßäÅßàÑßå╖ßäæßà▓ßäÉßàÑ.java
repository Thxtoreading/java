package 생성자;

public class 컴퓨터 {

	public static void main(String[] args) {
		컴퓨터조립 computer = new 컴퓨터조립(10000, "APPLE", 30 );
		컴퓨터조립 computer2 = new 컴퓨터조립(20000, "BANANA", 30 );
		System.out.println(computer);
		System.out.println(computer2);
		
	}

}
