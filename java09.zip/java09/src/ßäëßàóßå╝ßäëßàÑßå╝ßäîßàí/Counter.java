package 생성자;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Counter {
	
	static int count;

	public static void main(String[] args) {
		JFrame f = new JFrame("나의 카운터 프로그램");
		f.setSize(400, 300);
		f.getContentPane().setBackground(Color.lightGray);

		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);

		Font font = new Font("나눔고딕", Font.BOLD, 150);
		Font font2 = new Font("나눔고딕", Font.BOLD, 18);

		JLabel countLabel = new JLabel(count + "");
		countLabel.setFont(font);
		
		JButton plus = new JButton("1더하기");
		plus.setFont(font2);
		plus.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				count++;
				countLabel.setText(count + "");

			}
		}); // action end
		JButton reset = new JButton("0으로 초기화");
		reset.setFont(font2);
		reset.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				count = 0;
				countLabel.setText(count + "");
				
			}
		}); // action end
		
		JButton minus = new JButton("1빼기");
		minus.setFont(font2);
		minus.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				count--;
				countLabel.setText(count + "");
				
			}
		}); // action end
		
		plus.setForeground(Color.red);
		minus.setForeground(Color.blue);

		f.add(plus);
		f.add(reset);
		f.add(minus);
		f.add(countLabel);

		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);

	}

}
