package 생성자;

public class 수강신청 {
	String subject;
	String time;
	String name;
	public 수강신청(String subject, String time, String name) {
		super();
		this.subject = subject;
		this.time = time;
		this.name = name;
	}
	@Override
	public String toString() {
		return "수강신청 [수강과목= " + subject + ", 수강시간= " + time + ", 수강생이름= " + name + "]";
	}
	
	
}
