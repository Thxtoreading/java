package 생성자;

public class 통장 {
	String names; //이름
	String ssn; //주민번호
	int money; //돈
	
	
	public 통장(String names, String ssn, int money) {
		super();
		this.names = names;
		this.ssn = ssn;
		this.money = money;
	}


	@Override
	public String toString() {
		return "통장 [names=" + names + ", ssn=" + ssn + ", money=" + money + "]";
	}
	

}
