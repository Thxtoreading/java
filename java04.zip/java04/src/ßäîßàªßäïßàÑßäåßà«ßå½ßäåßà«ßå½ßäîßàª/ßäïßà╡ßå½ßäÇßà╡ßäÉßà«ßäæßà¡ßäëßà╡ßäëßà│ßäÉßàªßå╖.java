package 제어문문제;

import java.util.Scanner;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class 인기투표시스템 {

	public static void main(String[] args) {
		//누적 시키는 변수는 반복문 안에 넣지 않는다!
		
		//부품 
		Scanner sc = new Scanner(System.in);
		int data = 0;
		int iu = 0;
		int bts = 0;
		int newj = 0;
		
		//반복문 시작
			System.out.println("당신이 좋아하는 사람의 숫자를 선택해 주세요.\n\n==============================\n"); //제목
			while (true) {
			System.out.println("1) 아이유 2) 방탄 3) 뉴진스 4)종료"); //선택지
			data = sc.nextInt();
			
			//선택지 처리
			if (data == 4) {
				System.out.println("투표를 종료합니다.");
				break;
			} else if (data == 1) {
				iu++;
			}else if (data == 2) {
				bts++;
			} else if (data == 3) {
				newj++;
			} else {
				System.out.println("해당 번호가 없습니다.");
			}
		}
		sc.close();
		
		//결과 
		System.out.println("---------------------");
		System.out.println("아이유 " + iu + "표 \n 방탄 " + bts + "표 \n 뉴진스 " + newj + "표");
		
		System.out.println("---------------------");
		

		
		
		
	}

}
