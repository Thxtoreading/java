package 제어문문제;

import java.util.Random;

public class 로또번호생성기 {

	public static void main(String[] args) {
		//아무값이나 발생시키는 부품 ==> Random
		//가짜 랜덤을 만들어 주는 부품도 됨.
		Random r = new Random(); //괄호 안 값이 씨앗값, seed값이라고 함
		
		for (int i = 0; i < 6; i++) {
			System.out.println("로또 번호: " + (r.nextInt(45) + 1)); //int만 범위 잡을 수 있음. 실수는 지금 안 됨!
			//괄호 안에 10이라고 쓰면 0~9까지 중 랜덤으로 나옴
		}
		
		//2 ~ 10
		for (int i = 0; i < 6; i++) {
			System.out.println("번호: " + (r.nextInt(9) + 2));			
		}
		
		//3 ~ 30
		for (int i = 0; i < 6; i++) {
			System.out.println("번호: " + (r.nextInt(28) + 3));			
		}
		
	}

}
