package 제어문문제;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class 오늘의확인문제 {

	public static void main(String[] args) {
		//확인 문제 
		//1. id와 pw를 입력해서 id가 root이고, pw가 1234이면 로그인 성공, 아니면 로그인 실패 출력
		
		//스캐너 설정
		Scanner sc = new Scanner(System.in);
		System.out.println("아이디를 입력해 주세요. (영문 네 자리)");
		String id = sc.next();
		System.out.println("패스워드를 입력해 주세요. (숫자 네 자리)");
		int pw = sc.nextInt(); //String이 조금 더 좋았을 듯 ㅠ.
		
		System.out.println("-------------------------------------");
		
		//조건이 여러개인 경우 ==> 논리연산자 (조건1 && 조건2)
		// 결과값 부분
		if (id.equals("root") && pw == 1234) {
			JOptionPane.showMessageDialog(null, "로그인에 성공하셨습니다!");
		} else {
			JOptionPane.showMessageDialog(null,"로그인 실패. 아이디 혹은 패스워드를 다시 확인해 주세요.");
		}
		sc.close();
	}

}
