package 제어문문제;

import java.util.Scanner;

public class 오늘의확인문제3 {

	public static void main(String[] args) {
		//심화 문제
		// 3. - 시작값, 종료값 입력
		//     시작값부터 종료값까지 모두 더해서 출력
		Scanner sc = new Scanner(System.in);
		System.out.println("시작값 >>  ");
		int start = sc.nextInt();
		
		System.out.println("종료값 >>   ");
		int end = sc.nextInt();
		
		int sum = 0;
		for (int i =start; i < end; i++) {
			sum = sum + i;
		}
		System.out.println(start + "부터" + end+ "까지의 합은 >>  " + sum);
		
		sc.close();
		//4. 시작값, 종료값, 점프값 입력
				//    시작값부터 종료값까지 점프값만큼 증가하면서 더함. 더한 값을 출력
				//    더한 값이 100을 넘으면 프로그램 종료
	}

}
