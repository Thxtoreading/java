package 제어문문제;

import java.util.Scanner;

public class 오늘의확인문제2 {

	public static void main(String[] args) {
		//확인문제
		//2. 사과 구매 갯수, 사과 한 개당 가격 입력 / 딸기 구매 갯수, 딸기 한 개당 가격 입력
		//    다음과 같이 출력 
		//    사과 구매 가격은 5500원입니다. 딸기 구매 가격은 4500원 입니다. 전체 구매 가격은 10000원 입니다.
		Scanner sc = new Scanner(System.in);
		System.out.println("몇 개의 사과를 구매하셨나요?");
		int ap = sc.nextInt();
		System.out.println("하나의 사과는 얼마인가요?");
		int pr = sc.nextInt();
		System.out.println("몇 개의 딸기를 구매하셨나요?");
		int st = sc.nextInt();
		System.out.println("하나의 딸기는 얼마인가요?");
		int pr2 = sc.nextInt();
		
		System.out.println("-----------------------------");
		
		int aTotal = ap * pr;
		int bTotal = st * pr2;
		int AllTotal = aTotal + bTotal;
		System.out.println("사과의 구매 가격은 " + aTotal  + "원 입니다.");
		System.out.println("딸기의 구매 가격은 " + bTotal + "원 입니다.");
		System.out.println("전체 구매 가격은 " + AllTotal + "원 입니다.");
		
		sc.close();
	}

}
