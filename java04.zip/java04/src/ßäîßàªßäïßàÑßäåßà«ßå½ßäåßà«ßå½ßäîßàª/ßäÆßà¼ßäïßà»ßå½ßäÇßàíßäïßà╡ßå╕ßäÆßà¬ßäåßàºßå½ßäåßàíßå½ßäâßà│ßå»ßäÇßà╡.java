package 제어문문제;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class 회원가입화면만들기 {

	public static void main(String[] args) {
		//아이디, 패스워드, 이름, 전호번호 입력, 회원가입 처리 버튼
		
		JFrame fr = new JFrame();
		fr.setSize(500, 600); 
		
		FlowLayout flow = new FlowLayout();
		fr.setLayout(flow);
		
		//이미지
		ImageIcon img = new ImageIcon("naver/nalogo.png");
		
		//이미지, 글씨
		JLabel label = new JLabel();
		label.setIcon(img);
		JLabel id1 = new JLabel();
		id1.setText("사용할 아이디를 입력해 주세요.");
		JLabel pw1 = new JLabel();
		pw1.setText("사용할 패스워드를 입력해 주세요.");
		JLabel name1 = new JLabel();
		name1.setText("이름을 입력해 주세요.");
		JLabel num1 = new JLabel();
		num1.setText("전화번호를 입력해 주세요.");
		
		//글씨 넣는 곳
		JTextField id = new JTextField(13);
		JTextField pw = new JTextField(13);
		JTextField name = new JTextField(13);
		JTextField num = new JTextField(13);
		
		//버튼
		JButton b = new JButton();
		b.setText("회원가입처리");
		
		
		
		//폰트
		Font font = new Font("나눔고딕", 1, 30);
		Font font2 = new Font("나눔고딕", 1, 20);
		
		id.setFont(font);
		id1.setFont(font2);
		pw.setFont(font);
		pw1.setFont(font2);
		name.setFont(font);
		name1.setFont(font2);
		num.setFont(font);
		num1.setFont(font2);
		
		
		//프레임에 추가
		fr.add(label);
		fr.add(id1);
		fr.add(id);
		fr.add(pw1);
		fr.add(pw);
		fr.add(name1);
		fr.add(name);
		fr.add(num1);
		fr.add(num);
		fr.add(b);
		
		b.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String ide = id.getText();
				String pas = pw.getText();
				String nam = name.getText();
				String numb = num.getText();
				if (ide.equals("") || pas.equals("") || nam.equals("") || numb.equals("")) {
					JOptionPane.showMessageDialog(fr, "무언가 빠뜨리셨군요... ㅡㅡ^");
				} else {
					JOptionPane.showMessageDialog(fr, nam + " 님 회원가입을 축하드립니다 ^_^!");
				}
				
			}
			
		});
		
		fr.setVisible(true);
	}

}
