package 제어문문제;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class 인기투표JF2 {

	public static void main(String[] args) {
		
		//버튼 3개, 라벨 7개, 제목 하나
		JFrame f = new JFrame();
		f.setSize(350, 500);
		
		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);
		
		//폰트 설정
		Font font1 = new Font("나눔고딕", 1, 40);
		Font font2 = new Font("나눔고딕", 1, 20);
		Font font3 = new Font("나눔고딕", 1, 15);
		
		//버튼 이미지
		ImageIcon img1 = new ImageIcon("naver/iuli.png");
		ImageIcon img2= new ImageIcon("naver/btsbu.png");
		ImageIcon img3 = new ImageIcon("naver/newjeans.png");		
		
		//버튼
		JButton b1 = new JButton();
		b1.setIcon(img1);
		JButton b2 = new JButton();
		b2.setIcon(img2);
		JButton b3 = new JButton();
		b3.setIcon(img3);
		JButton b4 = new JButton();
		b4.setText("투표 마감");
		b4.setPreferredSize(new Dimension(200, 50));
		
		//글자 부분
		JLabel title = new JLabel();
		title.setText("K-pop 인기 투표");
		JLabel la1 = new JLabel(); 
		la1.setText("1. 아이유 - 라일락");
		JLabel la2 = new JLabel();
		la2.setText("2. BTS - butter");
		JLabel la3 = new JLabel(); 
		la3.setText("3. 뉴진스 - OMG");
		JLabel la4 = new JLabel(); //아이유 투표
		JLabel la5 = new JLabel(); //방탄소년단
		JLabel la6 = new JLabel(); //뉴진스
		
		//폰트 설정
		title.setFont(font1);
		la1.setFont(font2);
		la2.setFont(font2);
		la3.setFont(font2);
		la4.setFont(font2);
		la5.setFont(font2);
		la6.setFont(font2);
		b4.setFont(font3);
		
		//색상
		f.getContentPane().setBackground(Color.blue);
		
		//프레임에 추가
		f.add(title);
		f.add(b1);
		f.add(la1);
		f.add(la4);
		
		f.add(b2);
		f.add(la2);
		f.add(la5);
		
		f.add(b3);
		f.add(la3);
		f.add(la6);
		
		f.add(b4);
		
		//버튼 클릭 시 설정
		b1.addActionListener(new ActionListener() {
			int iu = 0;
			
			@Override
			public void actionPerformed(ActionEvent e) {
					iu++;
					la4.setText(iu + "표");
			}
		});
		b2.addActionListener(new ActionListener() {
			int bts = 0;
			
			@Override
			public void actionPerformed(ActionEvent e) {
				bts++;
				la5.setText(bts + "표");
			}
		});
		b3.addActionListener(new ActionListener() {
			int newj = 0;
			
			@Override
			public void actionPerformed(ActionEvent e) {
				newj++;
				la6.setText(newj + "표");
			}
		});
		b4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(f, "  투표가 마감되었습니다. \n즐거운 하루 보내세요 ^_^");
			}
		});
		
		f.setVisible(true);
		
		
	}

}
