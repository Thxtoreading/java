package 제어문문제;

import java.util.Random;
import java.util.Scanner;

public class 숫자맞추기게임 {

	public static void main(String[] args) {
		
		Random r = new Random();
		Scanner sc = new Scanner(System.in);
		
		int target = r.nextInt(100); //0~99
		int data = 0; 
		int count = 0;
		
		//반복문 시작
		while (true) {
			System.out.println("당신이 생각하는 숫자는? ");
			data = sc.nextInt();
			count++;
			if (data == target) {
				System.out.println("정답입니다! ^_^");
				System.out.println("당신의 시도 횟수는 " + count + "번 입니다.");
				System.out.println("프로그램을 종료합니다.");
				break;
			} else {
				System.out.println("오답입니다. ㅠ_ㅠ");
				
				//data가 target보다 크면 "너무 커요" 작으면 "너무 작아요"를 힌트로 출력
				if (data > target) {
					System.out.println("현재 숫자가 너무 큽니다.");
				} else if (data < target) {
					System.out.println("현재 숫자가 너무 작습니다.");
				}
				
				System.out.println("다시 시도해 주세요.");
				System.out.println("----------------------------");
			} 
		}
		sc.close();
	}

}
