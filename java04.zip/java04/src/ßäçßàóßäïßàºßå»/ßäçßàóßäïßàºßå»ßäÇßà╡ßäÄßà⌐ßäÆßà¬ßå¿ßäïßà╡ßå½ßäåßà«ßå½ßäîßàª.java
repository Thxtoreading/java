package 배열;

public class 배열기초확인문제 {

	public static void main(String[] args) {
		//전체 만들어지는 변수의 개수는 7개
		
		// 배열 값 설정, 프린트
		int[] s = new int[5];
		System.out.println("배열의 크기는 " + s.length);
		s[0] = 100;
		System.out.println(s[0]);
		s[4] = 500;
		System.out.println(s[4]);
		s[2] = 200;
		System.out.println(s[2]);

		// 배열 전체 데이터 프린트
		for (int i = 0; i < s.length; i++) {
			System.out.print(s[i] + " ");
		}
		System.out.println();

		// 배열 전체 데이터와 인덱스 프린트
		for (int i = 0; i < s.length; i++) {
			System.out.print("s[" + i + "]= " + s[i] + " ");
		}

	}

}
