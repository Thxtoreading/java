package 배열;

public class 배열개념 {

	public static void main(String[] args) {
		// 여러 개의 데이터를 램에 저장해 두고 cpu가 접근하여
		// 사용하고 싶은 경우 사용하는 부품
		// 1. 값을 이미 알고 있는 경우
		int[] jumsu = { 10, 20, 30, 40 }; // length 만들어서 몇개인지 세서 값을 넣어줌
		// System.out.println(jumsu);
		System.out.println(jumsu[0]); // 1번째 값을 출력
		System.out.println(jumsu[1]);
		System.out.println(jumsu[2]);
		System.out.println("전체 개수: " + jumsu.length); // 배열 안에 들어있는 데이터 수를 프린트
		// 공간과 length 공간 합해서 공간은 total 5개 만들어짐

		jumsu[0] = 100;
		System.out.println(jumsu[0]);
		// 공간 안의 값을 정해놓고 그 공간을 출력

		// 2.값을 아직 모르는데, 먼저 저장공간 만들어두고 나중에 값을 넣는 경우
		int[] jumsu2 = new int[4];
		jumsu[0] = 200;
		System.out.println(jumsu[0]);
		// 공간을 정해 놓고 그 안에 값을 넣어서 출력

	}

}
