package 배열;

public class 배열다루기 {

	public static void main(String[] args) {
		int[] x = new int[10]; // length: 10
		// index는 0부터 시작, 마지막 위치는 인덱스의 개수보다 작음
		// 0~9
		System.out.println(x.length);
		x[0] = 10;
		x[1] = 20;

		for (int i = 0; i < x.length; i++) {
			System.out.print(x[i] + " ");
		} // for을 쓰면 바로 배열을 찾아서 써줌
			// 반복문과 배열을 함께 써서 출력

//		System.out.println(x[0]);
//		System.out.println(x[1]);

		// 우리가족의 이름을 string으로 저장, 프린트
		// 우리가족의 성별을 char로 저장, 프린트
		// 우리가족의 시력을 double으로 저장, 프린트
		// 우리가족의 점심 여부를 boolean으로 저장, 프린트

		System.out.println();

		String[] name = { "김나혜", "정상현", "정서현" };
		for (int i = 0; i < name.length; i++) {
			System.out.print(name[i] + " ");
		}
		System.out.println();

		char[] gender = { '여', '남', '여' };
		for (int i = 0; i < gender.length; i++) {
			System.out.print(gender[i] + " ");
		}
		System.out.println();

		double[] sight = { 1.0, 0.8, 0.6 };
		for (int i = 0; i < sight.length; i++) {
			System.out.print(sight[i] + " ");
		}
		System.out.println();

		boolean[] lunch = { true, true, true };
		for (int i = 0; i < lunch.length; i++) {
			System.out.print(lunch[i] + " ");
		}

		System.out.println();

	}

}
