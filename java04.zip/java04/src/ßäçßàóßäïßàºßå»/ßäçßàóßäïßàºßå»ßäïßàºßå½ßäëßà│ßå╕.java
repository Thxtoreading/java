package 배열;

public class 배열연습 {

	public static void main(String[] args) {
		// 연습문제
		// 값을 아는 배열
		// 1. 배열에 일주인 간 공부한 시간을 저장해 보세요.
		// {1,2,3,4,5,6,7} 배열 이름 - week
		int[] week = { 1, 2, 3, 4, 5, 6, 7 };

		// 2. 첫번째 위치와 두번째 위치값을 프린트
		System.out.println(week[1] + "\n" + week[2]);

		// 3. week 배열에 들어 있는 데이터 수를 프린트
		System.out.println(week.length);

		// 4. 세 번째 위치값을 10으로 넣어주세요.
		// 다섯 번째 위치값을 12로 넣어주세요.
		week[3] = 10;
		week[5] = 12;

		// 5. 세번쨰, 다섯번째 위치값을 프린트
		System.out.println(week[3] + "\n" + week[5]);

		
		// 값을 모르는 배열
		// 6. 배열을 처음 만들 때 값은 모르지만 크기는 4개인 저장공간은 만들자. 배열 이름 tour
		int[] tour = new int[4];

		// 7. 첫번째 인덱스에 20, 세 번째 위치에 30을 넣고나서 프린트
		tour[1] = 20;
		tour[3] = 20;
		System.out.println(tour[1] + "\n" + tour[3]);

		// 8. tour변수의 개수를 프린트
		System.out.println(week.length);

	}

}
