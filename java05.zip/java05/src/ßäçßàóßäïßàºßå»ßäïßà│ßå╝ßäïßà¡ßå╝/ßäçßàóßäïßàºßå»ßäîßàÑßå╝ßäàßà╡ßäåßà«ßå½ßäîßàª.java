package 배열응용;

import java.util.Scanner;

public class 배열정리문제 {

	public static void main(String[] args) {
		// 스캐너 사용해서 문제 풀기
		// 1. 정수 5개 크기의 배열을 만들어서 10, 20, ... , 50을 순서대로 넣음
		// 첫번째 값과 세번째 값을 더해서 프린트
		Scanner sc = new Scanner(System.in);
		int[] num = new int[5];

		for (int i = 0; i < num.length; i++) {
			System.out.println("정수를 입력해 주세요. >>   ");
			num[i] = sc.nextInt();
		} // for문
		System.out.println(num[0] + num[2]);

		System.out.println();

		// 2. 스트링 3개 크기의 배열을 만들어서 자바, 스프링, JSP를 순서대로 넣음
		// => "자바 보다는 스프링"으로 출력
		String[] word = new String[3];

		for (int i = 0; i < word.length; i++) {
			System.out.println("글자를 입력해 주세요. >>   ");
			word[i] = sc.next();

		} // for문
		System.out.println(word[0] + "보다는 " + word[1]);
		
		sc.close();

	}

}
