package 배열응용;

public class 여러개배열사용하기2 {
	public static void main(String[] args) {
		// 1. 2학기 성적이 오른 학생은 몇명?
		// 2. 1학기, 2학기 성적이 동일한 학생 몇 명?
		// 3. 2학기 학생 중 만점(100)인 학생의 이름과 번호는?
		// 4. 1학기 성적의 평균과 2학기 성적의 평균 중 언제가 더 높았나요?
		// 5. 심화) 뉴진스의 1학기 성적, 2학기 성적은?
		
		String[] names = { "홍길동", "이순신", "뉴진스", "방탄", "블랙핑크" };
		int[] term1 = { 77, 88, 99, 55, 70 }; // 1학기
		int[] term2 = { 99, 100, 88, 80, 70 }; // 2학기
		
		int differentCount = 0; 
		int sameCount = 0;

		for (int i = 0; i < term1.length; i++) {
			if (term2[i] > term1[i]) {
				differentCount++;
			} else if (term1[i] == term2[i]) {
				sameCount++;
			}
			if (term2[i] == 100) {
				System.out.println("만점인 학생은 " + (i + 1) + "번 " + names[i] + "입니다.");
			}

		} // for
		
		System.out.println("2학기 성적이 오른 학생 수는 " + differentCount + "명 입니다.");
		System.out.println("1-2학기 성적이 동일한 학생 수는 " + sameCount + "명 입니다.");

		int sum = 0;
		int sum2 = 0;
		for (int x : term1) {
			sum += x;
		}
		for (int y : term2) {
			sum += y;
		}
		
		//평균 
		double avg = (double)sum / term1.length;
		double avg2 = (double)sum / term2.length;
		
		if (avg > avg2) {
			System.out.println("평균 성적은 1학기가 더 높습니다.");
		} else {
			System.out.println("평균 성적은 2학기가 더 높습니다.");
		}
		
		for (int i = 0; i < term2.length; i++) {
			if (names[i].equals("뉴진스")) {
				System.out.println("뉴진스의 1학기 성적은 " + term1[i] + " 점이고, \n 2학기 성적은 " + term2[i] + "점 입니다.");
			}
		}


	}

}
