package 배열응용;

import java.util.Iterator;
import java.util.Random;

public class 우리반성적변동 {

	public static void main(String[] args) {
		Random r = new Random(42);

		int[] n1 = new int[10000];
		int[] n2 = new int[10000];

		for (int i = 0; i < n2.length; i++) {
			n1[i] = r.nextInt(101);
			n2[i] = r.nextInt(101);
		}

		int sameCount = 0; // 동일한 갯수 누적
		int differentCount = 0; // 동일하지 않은 갯수 누적
		int upCount = 0; //2학기 점수가 더 큰 경우
		int downCount = 0; //1학기 점수가 더 큰 경우

		for (int i = 0; i < n2.length; i++) {
			// System.out.println(n1[i] == n2[i]);
			if (n1[i] == n2[i]) {
				sameCount++;
			} else {
				differentCount++;
				if (n2[i] > n1[i]) {
					upCount++;
					System.out.println("1학기 성적이 더 큰 학생은 " + i);
				} else {
					downCount++;
					System.out.println("2학기 성적이 더 큰 학생은 " + i);
				}
			}
		} // for
		System.out.println("1-2학기 성적이 동일한 학생 수 >> " + sameCount + "명");
		System.out.println("1-2학기 성적이 동일하지 않은 학생 수 >> " + differentCount + "명");

		// 2학기에 성정이 더 오른 학생은 몇명? 누구?
		// 1학기에 성적이 더 좋았던 학생은 몇명? 누구?

		for (int i = 0; i < n2.length; i++) {

		} // for문
		System.out.println("2학기에 성적이 오른 학생 수는 " + upCount + "명");
		System.out.println("1학기에 성적이 더 좋았던 학생 수는 " + downCount + "명");

	}

}
