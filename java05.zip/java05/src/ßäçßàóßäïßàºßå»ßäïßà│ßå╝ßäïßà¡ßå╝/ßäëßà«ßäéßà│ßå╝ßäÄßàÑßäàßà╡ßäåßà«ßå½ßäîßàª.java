package 배열응용;

import java.util.Iterator;
import java.util.Random;

public class 수능처리문제 {

	public static void main(String[] args) {
		// 수능 10,000명의 점수를 처리!
		// 랜덤으로 만명의 점수를 넣어주세요. 0 ~ 450
		// 만점자가 몇 명인지? 누구인지(인덱스)
		// 0점이 몇명인지?
		// 평균은 어떻게 되었는지? 합계 먼저 구하기
		// foreach 자주 사용할 수 있도록 자주 써보기
		// 자바는 +- 연산자 안 됨. 
		
		int[] jumsu = new int[10000];
		Random r = new Random(42);

		for (int i = 0; i < jumsu.length; i++) {
			jumsu[i] = r.nextInt(451);
			}
		
		//foreach 쓰는게 좋음. 짧고 단순해지기 때문에
		
		int minCount = 0;
		int maxCount  = 0;
		for (int x : jumsu) {
			if (x == 0) {
				minCount++;
			}
			if (x == 450) {
				maxCount++;
				
			}
		} // for문
		System.out.println("만점자는 총 " + maxCount + "명 입니다. " ); //1번
		System.out.println("0점인 사람은 " + minCount + "명 입니다."); // 2번

		int sum = 0;
		for (int x : jumsu) {
			sum = sum + x;
		} //for문
		double avg = (double)sum / jumsu.length;
		System.out.println("올해의 평균은 " + avg + "점 입니다."); //3번
		
		int count3 = 0;
		for (int x : jumsu) {

			if ( (avg - 50 <= x) && ( x <= avg + 50)) {
				count3++;
			}
		}//for문
		System.out.println("평균 언저리인 사람은 " + count3 + "명 입니다."); //4번
		
		//상위 30% 점수의 30% 미친 거 궁그매 죽겟네 
		//10,000 * 30퍼 / 100 //상위 30퍼 = 3000명 // 정렬이 되어 있어야 
		System.out.println((450*0.3) / 100);

	}

}
