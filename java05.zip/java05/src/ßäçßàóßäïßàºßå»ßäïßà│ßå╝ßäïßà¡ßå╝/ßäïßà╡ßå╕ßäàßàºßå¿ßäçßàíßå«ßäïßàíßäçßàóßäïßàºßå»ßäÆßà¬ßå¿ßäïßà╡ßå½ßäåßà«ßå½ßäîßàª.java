package 배열응용;

import java.util.Iterator;
import java.util.Scanner;

public class 입력받아배열확인문제 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] lastTrip = new String[3];
		String[] nowTrip = new String[3];

		for (int i = 0; i < lastTrip.length; i++) {
			System.out.println("작년에 가고 싶었던 곳 " + (i + 1) + "순위를 적어주세요. >>   ");
			lastTrip[i] = sc.next();
		} // for문

		for (int i = 0; i < nowTrip.length; i++) {
			System.out.println("올해 가고 싶은 곳 " + (i + 1) + "순위를 적어주세요. >>   ");
			nowTrip[i] = sc.next();
		} // for문
		int count = 0;
		for (int i = 0; i < nowTrip.length; i++) {
			if (lastTrip[i].equals(nowTrip[i])) {
				count++;
				//System.out.println(count);
			}
		} // for문
		System.out.println("작년과 올해 가고 싶은 곳과 우선 순위가 동일한 곳은 " + count + "곳 입니다.");
		
		

		sc.close();
	}

}
