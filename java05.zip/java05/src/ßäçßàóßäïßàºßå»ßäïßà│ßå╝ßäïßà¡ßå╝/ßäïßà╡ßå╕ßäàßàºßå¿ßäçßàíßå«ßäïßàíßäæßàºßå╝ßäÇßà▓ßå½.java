package 배열응용;

import javax.swing.JOptionPane;

public class 입력받아평균 {

	public static void main(String[] args) {
		// 입력을 여러 번 여러 개 받아서 저장 공간에 넣곻 싶을 때 => 배열 사용
		// 1. 배열을 만들기
		int[] jumsu = new int[5];

		// 배열에 값을 넣을 때는 index가 필요 ==> i가 있는 for문 사용해야 함.
		for (int i = 0; i < jumsu.length; i++) {
			String data = JOptionPane.showInputDialog("숫자 입력");

			// 숫자로 변환한 값을 배열의 해당 인덱스에 값으로 넣자.
			// jumsu변수에 들어있는 주소가 가르키는 0번 인덱스 공간
			// 0??? --> 위치값, 인덱스
			jumsu[i] = Integer.parseInt(data);

		}
		for (int x : jumsu) {
			System.out.println(x + " ");
		}
		System.out.println();
		
		//1. 전체 합계 구해서, 평균 구해 보세요.
		int sum = 0;
		for (int i : jumsu) {
			sum = sum + i; // sum += i; 와 같은 의미
		}
		
		System.out.println("전체 합계는 " + sum);
		
		double avg = (double)sum / jumsu.length;
		System.out.println("평균은 " + avg);
		
		//2. 300이상 되는 숫자만 찾아서, 합계를 구해보세요.
		//3. 심화문제, 300이상 되는 위치인 index를 프린트
		
		int sum2 = 0;
		for (int i = 0; i < jumsu.length; i++) {
			if (jumsu[i] >= 300) {
				sum2 = sum2 + jumsu[i];
				System.out.println("300 이상 값이 저장된 index는 jumsu [" + i + "]");
			}
		}
		System.out.println("300 이상 되는 합계: " + sum2);
		
		
	}

}
