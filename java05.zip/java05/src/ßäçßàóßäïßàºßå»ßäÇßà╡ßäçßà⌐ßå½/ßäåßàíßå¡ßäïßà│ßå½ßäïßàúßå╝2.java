package 배열기본;

import java.util.Random;

public class 많은양2 {
	public static void main(String[] args) {
		// 2부터 20까지 임의로 만들어서 배열 안에 넣기
		// 전체 프린트
		// 3이상인 숫자 몇 개인지 프린트 //배열 전체를 가지고 와서 3이상인지 페크 후
		// 3이상인 개수를 세주세요. //나이거진차모르겟서ㅠㅠ!!!
		
		int [] jumsu2 = new int [100];
		Random r = new Random(42);
		
		for (int i = 0; i < jumsu2.length; i++) {
			jumsu2[i] = r.nextInt(19) + 2;
		}
		 for (int x : jumsu2) {
			System.out.println(x);
		}
		 
		 int count = 0;
		 int sum = 0;
		 for (int i = 0; i < jumsu2.length; i++) {
			if (jumsu2[i] >= 15) {
				count++;
				sum = sum + i;
			}
			
		}
		 System.out.println("15이상 갯수: " + count);
		 System.out.println("15이상 총합: " + sum);
	}

}
