package 배열기본;

//랜덤의 위치는 java 폴더 아래 util에 있음
import java.util.Random;

public class 많은양 {

	public static void main(String[] args) {
		int[] jumsu = new int [999];
		//for (int i : jumsu) {
			//System.out.println(i);
		//}
		System.out.println("=============");
		
		Random r = new Random();
		//int data = r.nextInt(4) + 1; //4만 쓰면 0~3이 나옴
		//System.out.println(data);
		
		for (int i = 0; i < jumsu.length; i++) {
			jumsu[i] = r.nextInt(4) + 1;
			for (int x : jumsu) {
				System.out.println(x);
			}
					}
		
	}

}
