package 복습;

public class 배열기본확인문제 {

	public static void main(String[] args) {
		//좋아하는 여행지 5개, 좋아하는 색깔 5개의 첫 글자, 좋아하는 연예인 5명의 키
		
		String [] trip = {"태국", "호주", "일본", "유럽", "러시아"};
		char [] color = {'r', 'b', 'g', 'o', 'y'};
		double [] heigth = {180.8, 190.4, 175.6, 178.4,  173.2};
		
		for (String x : trip) {
			System.out.println(x);
		}
		for (char y :color) {
			System.out.println(y);
		}
		for (double z : heigth) {
			System.out.println(z);
		}
	}

}
