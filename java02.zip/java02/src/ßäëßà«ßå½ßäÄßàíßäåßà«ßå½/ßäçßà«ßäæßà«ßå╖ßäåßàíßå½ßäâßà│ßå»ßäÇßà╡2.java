package 순차문;

public class 부품만들기2 {

	public static void main(String[] args) {
		//JFrame부품을 만들어 램에 저장
		//JButton부품을 만들어 램에 저장
		//JFrame에 버튼을 추가
		//버튼이 추가된 JFrame을 화면에 보이게 하기
	}

}
