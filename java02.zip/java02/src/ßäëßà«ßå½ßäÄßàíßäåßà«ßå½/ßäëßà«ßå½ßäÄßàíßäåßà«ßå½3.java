package 순차문;

import javax.swing.JOptionPane;

public class 순차문3 {

	public static void main(String[] args) {
		//입력 
		String tall = JOptionPane.showInputDialog("당신의 신장은 몇 cm입니?");
		String weight = JOptionPane.showInputDialog("당신의 체중은 몇 kg입니까?");
		
		//처리
		double tall2 = Double.parseDouble(tall);
		double weight2 = Double.parseDouble(weight);
		
		double bmi = weight2 / tall2 * tall2;
		
		//출력 
		System.out.println("당신의 bmi는 " + bmi + "입니다.");
		JOptionPane.showMessageDialog(null, bmi);
	}

}
