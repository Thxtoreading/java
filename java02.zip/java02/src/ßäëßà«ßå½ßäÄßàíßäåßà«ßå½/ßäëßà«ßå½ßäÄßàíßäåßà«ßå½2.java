package 순차문;

import javax.swing.JOptionPane;

public class 순차문2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//기본 순차문 == 입력 --> 처리 --> 출력
		//입력 -> 부품사용, 망치같은 언제나 바로 사용 가능 
		//다이얼로그 곳에서 입력한 값은 컴퓨터는 무조건 String으로 인식
		String data1 = JOptionPane.showInputDialog("정수를 입력하시오-1");
		String data2 = JOptionPane.showInputDialog("정수를 입력하시오-2");
		
		//처리 -> 숫자 더하기 연산 
		//String을 int로 변경해주어야 함
		int data11 = Integer.parseInt(data1); //"200"(문자) --> 200(숫자)
		int data22 = Integer.parseInt(data2); //"100"(문자) --> 100(숫자)
		
		double data33 = Double.parseDouble(data1);
		double data44 = Double.parseDouble(data2);
		
		int result = data11 + data22; 
		double result2 = data33 + data44;
		
		//data1 + 100 + 200
		//이렇게하면 순차적으로 계산하다 data1 + 100, 운동100200 이렇게 표시됨.
		//먼저 숫자로 계산하고 싶은 건 괄호로 묶기 //data1 +(100 + 200) 이렇
		
		//출력 -> 모니터 화면에 띄우고 싶음 
		System.out.println(result);
		System.out.println(result2);


	}

}
