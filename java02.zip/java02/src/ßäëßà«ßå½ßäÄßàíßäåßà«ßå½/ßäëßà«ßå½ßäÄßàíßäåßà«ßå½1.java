package 순차문;

import javax.swing.JOptionPane;

public class 순차문1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//기본 순차문 == 입력 --> 처리 --> 출력
		//입력 -> 부품사용, 망치같은 언제나 바로 사용 가능 
		String data1 = JOptionPane.showInputDialog("당신의 취미는?");
		String data2 = JOptionPane.showInputDialog("언제 하시나요?");
		
		//처리 -> 글자연결 (+연산자 이용, 결합연산자)
		//더해지는 데이터가 하나라도 String이면 결과는 무조건 String 
		String result = data1 + " " + data2; //결과는 String
		
		//data1 + 100 + 200
		//이렇게하면 순차적으로 계산하다 data1 + 100, 운동100200 이렇게 표시됨.
		//먼저 숫자로 계산하고 싶은 건 괄호로 묶기 //data1 +(100 + 200) 이렇
		
		//출력 -> 모니터 화면에 띄우고 싶음 
		System.out.println(result);


	}

}
