package 복습;

public class 자바연산시주의사항 {

	public static void main(String[] args) {
		// 자바 연산 시 주의사
		int x = 20; //한줄 복사는 option + comm + 화살표 아래 
		int y = 30; 
		
		System.out.println(x / y); //기호가 나오면 CPU에서 처리
		//int 사용 시 값은 0이 나옴 //소수점까지 구하고 싶은 경우는 정수 사용 X
		//정수와 정수의 계산의 결과는 무조건 정수! 
		//계산 시 하나라도 실수이면 결과는 무조건 실수! 
		
		int x2 = 20;
		double y2 = 30; //30.0이라 double에 정수를 넣을 수 있음
		
		System.out.println(x2 / y2); 
		//연산자 앞 공백은 필수 아님, 그러나 보기 쉽게 권장하는 편
		
		//이미 정수로 저장된 값을 cpu가 가져다가 실수 연산을 하고 싶은 경우 
		//CPU가 정수를 실수로 변환해서 할 수 있음!
		//강제타입변환(강제형변환) ==> (강제로 바꾸고 싶은 타입)변수
		System.out.println(x / (double)y); 

	}

}
