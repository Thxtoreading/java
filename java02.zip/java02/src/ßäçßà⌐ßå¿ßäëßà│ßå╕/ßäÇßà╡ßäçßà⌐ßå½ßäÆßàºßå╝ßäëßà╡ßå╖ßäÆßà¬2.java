package 복습;

public class 기본형심화2 {

	public static void main(String[] args) {
		//정수형 변수 4가지
		//byte(-128~127), 1바이트 
		//short(-3만~3만), 2바이트 
		//int(-21억~21억), 4바이트 
		//long(21억 이상), 8바이트 
		
		byte age = 20;
		short days = 1200;
		int money = 100000;
		long bank = 2300000000L; //Long은 마지막에 L을 붙여줘야 
		//long bank = 2300000000; //옆처럼 쓰면 JDK는 int로 인식해서 오류로 판

		//실수형 변수 2가지 
		//소수점 4자리까지 float, 4바이트 
		//소수점 4자리 이상 double, 8바이트 
		
		float height = 170.4f; //float 사용 시 끝에 F를 써야함. 
		double weight = 43.333333;
		
		//문자형, 논리형 변수 1가지
		//char, boolean
		
		
		
	}

}
