package 복습;

public class 기본형심화 {

	public static void main(String[] args) {
		// 기본형 4가지 
		// 정수(int), 실수(double), 문자(char), 논리(boolean)
		double temp = 1.2; //세미콜론은 끝의 의미(끝낫당!)
		int floor = 20;
		char color = 'b';
		boolean water = true;
		
		String location = "당수동";
		
		//망치처럼 자주 사용하는 부품은 대문자로 바로 쓴다
		//system - 컴퓨터, out(출력장치) - 모니터
		//				 in(입력장치) - 키보
		System.out.println("오늘 온도는 " + temp + "도");
		System.out.println("지금 층수는 " + floor + "층");
		System.out.println("현재 의자의 색깔은 " + color + "rown");
		System.out.println("아침 물은 마셨는지? " + water);
		System.out.println("현재 위치는 " + location);
		
		
		
	}

}
