package 조건문;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class 연습문제1 { 
	
	public static void main(String[] args) {
		//연습문제 //1. 암호를 대시오 입력 ==> pass라고 입력
				//    암호가 맞으면 "들어오세요" 틀리면 "나가세요" 프린트
		String pw = JOptionPane.showInputDialog("암호를 대시오.");
		
		if (pw.equals("pass")) {
			System.out.println("들어오세요.");
		} else {
			System.out.println("나가세요.");
		}
		
		//연습문제 //2. 당신이 먹고 싶은 저녁 메뉴는? (자장면, 라면, 회)에서 선택
		//    자장면이면 "중국집으로 가요" 라면이면 "분식집으로 가요" 회이면 "횟집으로 가요" 없으면 "그냥 안 먹어요" 프린트


		String dinner = JOptionPane.showInputDialog("당신이 먹고 싶은 저녁 메뉴는?");
		switch (dinner) {
			case "자장면":
				System.out.println("중국집으로 가요");
				break;
			case "라면":
				System.out.println("분식집으로 가요");
				break;
			case "회":
				System.out.println("횟집으로 가요");
				break;

			default:
				System.out.println("그냥 안 먹어요.");
				break;
}
		
		//연습문제 //3. JOptionPane을 사용
				//    두 정수를 입력 받으세요. --> 누가 더 큰지 출력
		String n1 = JOptionPane.showInputDialog("첫번째 정수를 입력하세요.");
		String n2 = JOptionPane.showInputDialog("두번째 정수를 입력하세요.");
		
		int n11 = Integer.parseInt(n1);
		int n22 = Integer.parseInt(n2);
		
		if (n11 > n22 ) {
			System.out.println("첫번째 입력값이 더 큽니다.");
		} else if (n11 < n22 ) {
			System.out.println("두번째 입력값이 더 큽니다.");
		}else {
			System.out.println("두 수가 동일합니다.");
		}
		
		//연습문제 //4. 사원번호 ==> String no = "A100EX";
				//    맨 앞에 있는 글자를 추출 no.charAt(0)을 이용
				//    A이면 기획부, B이면 총무부, C이면 개발부, 아니면 해당부서없음 프린트
		String no = "A100EX";
		char ch = no.charAt(0);
		
		switch (ch) {
		case 'A':
			System.out.println("기획부");
			break;
		case 'B':
			System.out.println("기획부");
			break;
		case 'C':
			System.out.println("기획부");
			break;

		default:
			System.out.println("해당 부서없음.");
			break;
		}

		
	}
}
