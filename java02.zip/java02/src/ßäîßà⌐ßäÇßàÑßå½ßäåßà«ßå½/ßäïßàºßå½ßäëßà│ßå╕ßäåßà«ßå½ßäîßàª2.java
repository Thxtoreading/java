package 조건문;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class 연습문제2 { 
	
	public static void main(String[] args) {

		//JFrame, JLabel
		JFrame f = new JFrame();
		f.setSize(300, 300);
		
		JLabel label1 = new JLabel();
		label1.setText("당신이 먹고 싶은 메뉴는?");
		
		//JTextField
		JTextField text1 = new JTextField(10);
		
		//Font, FlowLayout
		Font font = new Font("굴림", 1, 20);
		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);
		
		//폰트 설
		label1.setFont(font);
		text1.setFont(font);
		
		//프레임에 추
		f.add(label1);
		f.add(text1);

		//색깔 설
		label1.setForeground(Color.black);
		text1.setForeground(Color.white);
		f.getContentPane().setBackground(Color.CYAN);
		
		//이 부분은 항상 마지막에 배치
		f.setVisible(true);
		
	}
}
