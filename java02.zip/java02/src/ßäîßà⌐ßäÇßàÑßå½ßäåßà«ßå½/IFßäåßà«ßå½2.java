package 조건문;

public class IF문2 {
	
	public static void main(String[] args) {
		//연습문제 //1. x와 y와 같은지 비교 후 같으면 "동일합니다"
				//    아니면 "동일하지 않아요" 프린트
		int x = 0;
		int y = 0;
		
		if (x == y) {
			System.out.println("동일합니다.");
		}else {
			System.out.println("동일하지 않아요.");
		}
		//연습문제 //2. id와 id2가 같은지 비교 후 같으면 "로그인 성공"
				//    아니면 "로그인 실패" 프린트
		int id = 1111;
		int id2 = 2222;
		
		if (id == id2) {
			System.out.println("로그인 성공");
		}else {
			System.out.println("로그인 실패");
		}
	}

}
