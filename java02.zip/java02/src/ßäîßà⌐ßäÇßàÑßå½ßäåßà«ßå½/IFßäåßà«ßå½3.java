package 조건문;

public class IF문3 { //조건이 여러개 일때
	
	public static void main(String[] args) {
		int myNum = 99;
		//if~else문 
		//break쓸 필요 없음
		
		//점수가 80점 이상이면 최우수
		if (myNum >= 80) {
			System.out.println("최우수");
		//점수가 70점 이상이면 우수
		} else if (myNum >= 70) {
			System.out.println("우수");
		//점수가 60점 이상이면 보통
		} else if (myNum >= 60) {
			System.out.println("보통");
		} else {
		//나머지는 미달
			System.out.println("미달");
		}
		
		//switch~case문 
		//break 필수, 마지막은 필요없음 지워도 돼
		int myTour = 10; //올해 여행 횟수
		//여행횟수가 10이면 "VVIP" 프린트
		switch (myTour) {
		case 10:
			System.out.println("VVIP");
			break;
		//여행횟수가 6이면 "VIP" 프린트
		case 6:
			System.out.println("VIP");
			break;
		//나머지 횟수이면, "Normal" 프린트 
		default:
			System.out.println("Normal");
			break;
		}
		

		
	}
}
