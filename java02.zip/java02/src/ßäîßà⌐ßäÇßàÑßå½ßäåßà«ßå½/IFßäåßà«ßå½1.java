package 조건문;

public class IF문1 {

	public static void main(String[] args) {
		int x = 0;
		
		//조건을 쓸 때는 비교하는 것으로 쓰고, 결과는 무조건 true/false
		//비교연산자(==, 1=, >, >=)로 비교할 수 있는 것은 기본형 데이터만 가능
		//아래 값은 true
		if (x == 0) { 
			System.out.println("내가 실행되겠지요??");
		}else {//false일 때 처리하고 싶은 내용을 쓰면 
			System.out.println("나는 조건이 맞지 않을 때 실행되는 거야");
		}
		
		//아래 값은 false
		if (x == 1) {
			System.out.println("나는 실행될까요??");
		}

	}

}
