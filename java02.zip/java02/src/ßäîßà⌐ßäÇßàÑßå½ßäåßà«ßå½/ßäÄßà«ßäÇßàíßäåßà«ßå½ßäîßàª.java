package 조건문;

import javax.swing.JOptionPane;

public class 추가문제 {
	public static void main(String[] args) {
		//입력
		String a = JOptionPane.showInputDialog("계산할 첫번째 숫자를 입력해 주세요.");
		String b = JOptionPane.showInputDialog("계산할 두번째 숫자를 입력해 주세요.");
		String c = JOptionPane.showInputDialog("계산에 사용할 연산자를 입력해 주세요.");
		
		//처리
		double A = Double.parseDouble(a);
		double B = Double.parseDouble(b);
		double result = 0;
		
		//출력
		switch (c) {
		case "+":
			result = A + B;
			System.out.println("값은 " + result + "입니다.");
			break;
		case "-":
			result = A - B;
			System.out.println("값은 " + result + "입니다.");
			break;
		case "*":
			result = A * B;
			System.out.println("값은 " + result + "입니다.");
			break;
		case "/":
			result = A / B;
			System.out.println("값은 " + result + "입니다.");
			break;

		default:
			System.out.println("연산자를 잘못 입력하셨습니다.");
			break;
		}
		//2. 두 수를 입력 받아 정수로 변환하여 정수변수에 저장,
		//   나누기 연산 수행 후 소숫점 2째자리까지 출력
		
		//입력
		String n1 = JOptionPane.showInputDialog("첫번째 정수를 입력해주세요.");
		String n2 = JOptionPane.showInputDialog("번째 정수를 입력해주세요.");
		
		//정수로 변환하여 정수 변수에 저장
		int n11 = Integer.parseInt(n1);
		int n22 = Integer.parseInt(n2);
		
		//나누기 연산 수행 후 소숫점 2째자리까지 출력
		double res = (double)n11/n22;
		System.out.printf("%.2f", res);
		
		
	}

}
