package 배열복습;

public class 이차원배열프린트2 {

	public static void main(String[] args) {
		//꼭 하고 싶은 것 9가지를 작성해서, 전체 프린트
		String[][] s = { 
				{ "방콕", "훗카이도", "노르웨이" }, 
				{ "뉴욕", "파타야", "영국" }, 
				{ "세부", "고베", "홍콩" } 
			}; // 전체를 프린트!
		for (int i = 0; i < s.length; i++) {
			for (int j = 0; j < s.length; j++) {
				System.out.print(s[i][j] + "\t");
			}
		}

	}

}
