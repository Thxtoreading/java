package 배열복습;

public class 스트링과배열2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
