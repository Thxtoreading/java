package 부품사용하기;

import 부품만들기.강아지;

public class 강아지사용하기 {

	public static void main(String[] args) {
		강아지 dog1 = new 강아지();
		dog1.type = "말티즈";
		dog1.height = 15.5;
		dog1.강아지가짓다();
		System.out.println("dog1의 품종: " + dog1.type);
		System.out.println("dog1의 키: " + dog1.height);
		
		강아지 dog2 = new 강아지();
		dog2.type = "포메라니안";
		dog2.height = 16.3;
		dog2.먹다();
		System.out.println("dog1의 품종: " + dog2.type);
		System.out.println("dog1의 키: " + dog2.height);
	}

}
