package 부품만들기;

public class TV {
	//멤버변수, 선언이 클래스 바로 아래 되었기에 
	//클래스 전체 영역에서 이 변수 사용 가능
	//이걸 전역변수(globalqustn, 글로벌 변수라고 부름)
	//멤버변수는 자동초기화, 전역변수도 자동초기화 (같은 말임)
	//전역변수는 자동초기화 O, 지역변수는 자동초기화 X <- 이게 가장 중요!
	
	public int ch; //= 0을 안 써도 됨. 쓰면 살짝 문법 모르는 애라고 생각
	public int vol;
	public boolean onOff; //false가 기본값
	
	public void 채널을바꾸다() {
		int change = 1; //괄호 안에서만 사용 가능, 지역변수, local변수, 로컬변수, 자동초기화 X
		System.out.println(ch + "에서 " + change + "로 바꾸다.");
	}
	
	public void 유튜브보다() { //메서드를 만드는 것 ==> 메서드 정의한다!
		System.out.println(vol + "을 키워서 동영상을 보다.");
	}
}
