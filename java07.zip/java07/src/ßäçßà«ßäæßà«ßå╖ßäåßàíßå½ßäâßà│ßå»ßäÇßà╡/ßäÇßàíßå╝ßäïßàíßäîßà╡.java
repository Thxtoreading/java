package 부품만들기;

public class 강아지 {
	public String type;
	public double height;
	
	public void 강아지가짓다() {
		System.out.println("왈왈");
		System.out.println("멍멍");
	}
public void 먹다() {
	System.out.println("밥을 먹는다");
	System.out.println("간식을 먹는다");
}
}
