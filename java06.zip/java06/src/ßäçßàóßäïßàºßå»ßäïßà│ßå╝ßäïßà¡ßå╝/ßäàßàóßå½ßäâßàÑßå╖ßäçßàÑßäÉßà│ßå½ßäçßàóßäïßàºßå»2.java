package 배열응용;

import java.util.Random;
import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;

public class 랜덤버튼배열2 {

	public static void main(String[] args) {
		// 1. 프레임을 만들어 보세요.
		JFrame f = new JFrame();
		f.setSize(1000, 800);

		// 레이아웃 부품 설정하지 않음.
		f.setLayout(null);

		// 3. 버튼을 넣을 배열을 먼저 만들어 두세요.
		JButton[] buttons = new JButton[500];

		// 4. 버튼을 500개 만들어서 배열에 넣어주세요. // 이거 밑에 for문에 넣어도 됨.
		
		
		Random r = new Random(42);
		Color [] colors = {Color.pink, Color.blue, Color.CYAN, Color.yellow};
		
		for (int i = 0; i < buttons.length; i++) {
			buttons[i] = new JButton(i + "번 버튼");
			int x = r.nextInt(800); // 가로 위치
			int y = r.nextInt(700);	 // 세로 위치
			// 5. 배열에 있는 버튼을 꺼내서 위치를 지정 후, f에 붙여주세요.
			buttons[i].setBounds(x, y, 100, 50);
			buttons[i].setForeground(colors[r.nextInt(colors.length - 1)]);
			f.add(buttons[i]);
		} //for문
		//심화-1)) 버튼 색을 몇 가지 지정해서 임의로 설정, 힌트 Color배열
		
		//심화-2)) f에 배경색을 넣어보세요.
		//f.getContentPane().setBackground(Color.lightGray);
		
		// 2. 프레임을 설정해 보세요. 실행해서 눈으로 확인
		f.setVisible(true);
	}

}
