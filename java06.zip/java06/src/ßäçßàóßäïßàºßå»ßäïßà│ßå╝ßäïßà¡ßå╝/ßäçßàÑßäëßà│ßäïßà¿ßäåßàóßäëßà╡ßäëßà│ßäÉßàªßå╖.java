package 배열응용;

import java.awt.Color;
import java.awt.Font;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class 버스예매시스템 {

	public static void main(String[] args) {
		JFrame f = new JFrame("버스예매시스템");
		f.setSize(800,1000);
		f.getContentPane().setBackground(Color.lightGray);
		
		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);
		
		Font font = new Font("나눔고딕", Font.BOLD, 30);
		JButton[]  btn = new JButton[100];
		
		JLabel result = new JLabel();
		result.setFont(font);
		
		int [] seat = new int [btn.length];
		
		for (int i = 0; i < seat.length; i++) {
			btn[i] = new JButton(i + 1 + "");
			btn[i].setFont(font);
			f.add(btn[i]);
		}
		
		//보이는 건 마지막에
		f.setVisible(true);
	}

}
