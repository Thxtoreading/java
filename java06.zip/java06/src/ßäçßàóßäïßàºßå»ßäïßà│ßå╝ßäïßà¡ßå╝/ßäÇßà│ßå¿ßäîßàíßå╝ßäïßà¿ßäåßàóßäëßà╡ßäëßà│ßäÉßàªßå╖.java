package 배열응용;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.naming.spi.DirStateFactory.Result;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class 극장예매시스템 {

	public static void main(String[] args) {
		// 프레임
		JFrame f = new JFrame(); // 이 괄호 안에 글자를 넣어도 타이틀로 사용 가능
		f.setTitle("극장예매 시스템");
		f.setSize(1000, 800);
		f.getContentPane().setBackground(Color.lightGray);

		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);

		Font font = new Font("나눔고딕", Font.BOLD, 30);
		JButton[] btn = new JButton[100];
		
		JLabel result = new JLabel("결과 보이는 곳");
		result.setFont(font);
		
		//예약 여부 저장하는 배열
		int[] seat = new int [btn.length];
		

		for (int i = 0; i < btn.length; i++) {
			btn[i] = new JButton(i +1 + "");
			btn[i].setFont(font);
			f.add(btn[i]);
			
			// 버튼에 액션기능 추가하기
			btn[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) { //e가 클릭하는 버튼의 글자를 가지고 와 주는 
					String text = e.getActionCommand();
					int no = Integer.parseInt(text);
					//이미 해당 좌석 번호가 1로 저장되어있는지 확인하고, 1이 아니면 예약 가능!
					if (seat[no] == 1) {
						result.setText("이미 예약된 좌석입니다.");
						result.setForeground(Color.blue);
					} else {
						seat[no] = 1;
						result.setText(text + "번 예약완료");
						result.setForeground(Color.red);
						btn[no-1].setText("예약");
						//btn[no-1].setEnabled(false);
					}
				}
			});
			
		}
		
		f.add(result);
		
		JButton total = new JButton("결제하기");
		total.setBackground(Color.blue);
		total.setForeground(Color.pink);
		total.setFont(font);

		f.add(total);
		
		total.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) { 
				int count = 0;
				String seatNo = "";
				for (int i = 0; i < seat.length; i++) {
					if (seat [i] == 1) {
						seatNo = seatNo + "" + i + "번 ";
								}
				}
				for (int x : seat) {
					if (x == 1) {
						count++;
						//seatNo = seatNo + " " + x;
					}
				} //for
				JOptionPane.showMessageDialog(f,"예매한 좌석은 " + seatNo + "입니다.");
				JOptionPane.showMessageDialog(f, (count*10000) + "원 결제하시면 됩니다.");
				
			}
		});

		f.setVisible(true);

	}

}
