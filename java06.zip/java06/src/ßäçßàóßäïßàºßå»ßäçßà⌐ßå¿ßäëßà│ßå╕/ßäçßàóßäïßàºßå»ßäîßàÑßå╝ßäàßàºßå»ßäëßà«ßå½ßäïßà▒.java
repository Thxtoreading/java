package 배열복습;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Random;

public class 배열정렬순위 {

	public static void main(String[] args) {
		// 정렬할 때는 arrays
		Random r = new Random(42); //씨앗값 (seed)
		int[] jumsu = new int[10000];
		//for: 입력, 출력, i활용 가능
		for (int i = 0; i < jumsu.length; i++) {
			jumsu[i] = r.nextInt(1000) + 1;
		}
		// for-each: 알아서 위치값을 옮겨주면서 하나씩 꺼내옵니다!
		for (int x : jumsu) {
			System.out.println(x);
		}
		//오름차순(작  --> 큰), 내림차순(큰 --> 작)
		Arrays.sort(jumsu);
		//==> jumsu가 바뀌어버림 (원본이 파괴) -> 파괴형 함
		//반대로 n에서 n2로 바꾸는 건 ram에 저장된 n이 변경된건 아님 (원본이 비파괴) -> 비파괴형 함수
		
		System.out.println("------------------------------");
		//정렬 후 확인
		for (int i : jumsu) {
			System.out.println(i);
		}
		//정렬 후 최대값, 최소값 프린트!
		System.out.println("최소값:: " + jumsu[0]);
		System.out.println("최대값: " + jumsu[jumsu.length - 1]);
		int sum30 = 0;
		for (int i = 7000; i < jumsu.length; i++) {
			sum30 = sum30 + jumsu[i];
		}
		System.out.println("상위 30% 평균: " + sum30 / 3000.0);
		
		int sum20 = 0;
		for (int i = 0; i < 3000; i++) {
			sum20 = sum20 + jumsu[i];
		}
		System.out.println("하위 30% 평균: " + sum20 / 3000.0);
		String result = Arrays.toString(jumsu);
		System.out.println(result);
	}

}
