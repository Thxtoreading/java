package 배열심화;

import java.util.Iterator;

public class 깊은복사응용 {

	public static void main(String[] args) {
		String [] subject = {"국어", "영어", "수학", "컴퓨터", "화학"};
		int[] score1 = {44, 66, 22, 99, 100};
		int[] score2 = score1.clone();
		score2[0] = 22;
		score2[2] = 88;
		
		for (int i = 0; i < score1.length; i++) {
			System.out.print(score1[i] + " ");
		}
		
		System.out.println(); //엔터
		
		for (int i = 0; i < score2.length; i++) {
			System.out.print(score2[i] + " ");
		}
		int sameCount = 0;
		int upCount = 0;
		for (int i = 0; i < score2.length; i++) {
			if (score1[i] == score2[i]) {
				sameCount++;
			} else if (score2[i] > score1[i]) {
				upCount ++;
				System.out.println("\n성적이 오른 과목은 " + subject[i]);
			}
			
		}//for
		System.out.println();
		System.out.println("1-2학기 동일한 성적의 과목 수는 " + sameCount + "개 입니다.");
		System.out.println("1-2학기 중 성적이 오른 과목 수는 " + upCount + "개 입니다.");

	}

}
