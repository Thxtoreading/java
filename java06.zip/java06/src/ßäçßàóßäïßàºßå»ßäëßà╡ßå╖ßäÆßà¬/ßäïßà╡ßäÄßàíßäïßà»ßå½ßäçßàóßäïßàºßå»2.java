package 배열심화;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class 이차원배열2 {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(500,400);
		
		String [] header = {"컴퓨터", "영어", "수학", "체육"};
		String [] [] contents = {
				{"100", "60", "90"},
				{"88", "87", "83"},
				{"99", "79", "89"},
				{"77", "78", "79"}
		};
		JTable table = new JTable(contents, header);
		JScrollPane scroll = new JScrollPane(table);
		f.add(scroll);
		
		f.setVisible(true);

	}

}
