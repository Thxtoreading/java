package 배열심화;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.Color;

public class 이차원배열 {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(500,200);
		String header [] = {"a", "b", "c"};
		String contents[] [] = {
				{"1", "2", "3"},
				{"1", "2", "3"},
				{"1", "2", "3"},
				{"1", "2", "3"},
				{"1", "2", "3"},
				{"1", "2", "3"},
				{"1", "2", "3"},
				{"1", "2", "3"},
				{"1", "2", "3"},
				{"1", "2", "3"},
				{"1", "2", "3"}
		};
		JTable table = new JTable(contents,header);
		//table.setShowHorizontalLines(true);
		//table.setShowVerticalLines(true);
		JScrollPane scroll = new JScrollPane(table);
		
		f.add(scroll);
		
		f.getContentPane().setBackground(Color.lightGray);
		
		f.setVisible(true);
				

	}

}
